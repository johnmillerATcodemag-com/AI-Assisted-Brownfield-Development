# Tools
# These are the tools available in this project. Use them as needed to assist with tasks.
# - `get_azure_best_practices`: Use this tool to retrieve Azure best practices for various operations.

# Rules for using tools in this project:
- @azure Rule - Use Azure Best Practices: When generating code for Azure, running terminal commands for Azure, or performing operations related to Azure, invoke your `get_azure_best_practices` tool if available.
